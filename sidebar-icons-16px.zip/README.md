# 16px 侧栏动态图标交付

包含 pin、folder-open、folder-minus、folder-tree、panel-left-open、panel-right-open、square-pen、align-left、book-open-text，共 9 个。

## 接入
React 使用 Icons.tsx（需 React 类型），同目录保留 icons.css。HTML 使用 example.html 中的内联 SVG 及 icons.css，无运行时动画依赖。

```tsx
import { FolderOpenIcon } from './Icons';
<button className="micro-icon-trigger"><FolderOpenIcon />文件夹</button>
```

触发类加在整行按钮或链接上。默认色 #4E5969，hover / focus-visible / is-selected / aria-current="page" / aria-pressed="true" 为 #1D2129。选中只改变颜色。支持减少动态效果。SVG 文件独立下载为静态图形，动画需内联 SVG 配合 CSS。

## 来源与适配
7 个图标来自 https://github.com/pqoqubbw/icons ，book-open-text 来自 https://github.com/ajitzero/animated-icons 。upstream 目录保留原始 React/Motion 与 Angular 组件供框架原版接入，需各自项目依赖，不能混用。
本包 Icons.tsx 与 icons.css 为统一无动画依赖适配，保留动作方向、部件分组与主要时序。Motion 弹簧转换成 CSS 缓动，folder-tree 描线统一使用 dashoffset，视觉曲线可能与上游有细微差别。Angular 版书本改用统一 hover / focus 触发与移出复位。PIN 沿用此前确认的自定义动效及 SVG。

默认显示 16px，24×24 viewBox，父元素 currentColor 控制颜色。使用按钮文字或 aria-label 提供名称。

已附上游 MIT 许可证，分发时保留。React 包装层需在实际项目中编译验证。

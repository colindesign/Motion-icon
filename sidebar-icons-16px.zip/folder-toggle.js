export function bindSpring(button){
let progress=0, velocity=0, opened=false, frame, previousTime;
function render(t){
 for(const svg of button.querySelectorAll("svg")){ const [back,front]=svg.querySelectorAll("path");
 const mix=(a,b)=>a+(b-a)*t;
 const right=mix(22,20);
 back.setAttribute('d',`M4 20 A2 2 0 0 1 2 18 V5 A2 2 0 0 1 4 3 H${mix(7.93,7.9)} A2 2 0 0 1 ${mix(9.6,9.59)} 3.9 L${mix(10.41,10.4)} 5.1 A2 2 0 0 0 12.1 6 H${right-2} A2 2 0 0 1 ${right} 8 V10`);
 const angle=t*Math.PI/3;
 const lift=4.8*(Math.cos(angle)-1+0.5*t);
 const reach=5*(Math.sin(angle)-Math.sin(Math.PI/3)*t);
 const edgeY=10-lift, tipX=mix(2,6)+reach;
 front.setAttribute('d',`M${tipX} ${mix(10,14)-lift} L${mix(2,7.5)+reach} ${mix(10,11.1)-lift} Q${mix(2,8.07)+reach} ${edgeY} ${mix(2,9.24)+reach} ${edgeY} H${mix(22,20)+reach} C${mix(22,21.31)+reach} ${edgeY} ${mix(22,22.27)+reach} ${mix(10,11.24)-lift} ${mix(22,21.94)+reach} ${mix(10,12.5)-lift} L${mix(22,20.4)} ${mix(18,18.5)} Q${mix(22,20.02)} 20 ${mix(20,18.45)} 20 H4`);
}}
const toggle=()=>{opened=!opened;button.setAttribute('aria-expanded',opened);const action=opened?'关闭':'打开';button.setAttribute('aria-label',action+'弹性文件夹');cancelAnimationFrame(frame);
 const goal=Number(opened);
 if(matchMedia('(prefers-reduced-motion: reduce)').matches){progress=goal;velocity=0;render(goal);return}
 previousTime=performance.now();
 function tick(now){
   const elapsed=Math.min((now-previousTime)/1000,0.05);previousTime=now;
   const steps=Math.max(1,Math.ceil(elapsed*240)),dt=elapsed/steps;
   for(let i=0;i<steps;i++){velocity+=((goal-progress)*450-velocity*(opened?26:32))*dt;progress+=velocity*dt}
   if(Math.abs(progress-goal)<0.001 && Math.abs(velocity)<0.015){progress=goal;velocity=0;render(goal);return}
   render(progress);frame=requestAnimationFrame(tick)
 }
 frame=requestAnimationFrame(tick)};
render(0);
 button.addEventListener("click",toggle);
 return ()=>{cancelAnimationFrame(frame);button.removeEventListener("click",toggle)};

}
export function bindHinge(hinge){
const toggle=()=>{const open=hinge.getAttribute('aria-expanded')==='false';hinge.setAttribute('aria-expanded',String(open));hinge.setAttribute('aria-label',(open?'关闭':'打开')+'侧倾文件夹')};
 hinge.addEventListener("click",toggle);
 return ()=>hinge.removeEventListener("click",toggle);
}

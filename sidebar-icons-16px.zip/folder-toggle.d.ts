export function bindSpring(button: HTMLButtonElement): () => void;
export function bindHinge(button: HTMLButtonElement): () => void;

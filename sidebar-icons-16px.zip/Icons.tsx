import type { SVGProps } from "react";
import "./icons.css";

export function PinIcon(props: SVGProps<SVGSVGElement>) {
  return (<svg {...props} className="micro-icon pin" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" xmlns="http://www.w3.org/2000/svg">
<path d="M17.0023 3.99976C17.0022 3.73398 16.8961 3.47862 16.7081 3.29067C16.5201 3.10285 16.2648 2.99749 15.999 2.99749H7.99936C7.73353 2.99749 7.47827 3.10275 7.29026 3.29067C7.10232 3.47862 6.99717 3.73398 6.99708 3.99976C6.99708 4.26559 7.10234 4.52085 7.29026 4.70885C7.47829 4.89688 7.73345 5.00301 7.99936 5.00301C8.52902 5.00301 9.03712 5.21294 9.41169 5.58743C9.7862 5.96193 9.997 6.47014 9.99708 6.99976V10.7605L9.98929 10.9689C9.95528 11.4535 9.80412 11.9238 9.54708 12.3384C9.25434 12.8105 8.83516 13.1908 8.33832 13.439L8.33929 13.44L6.55975 14.34L6.55293 14.3429C6.38592 14.426 6.24602 14.5546 6.14773 14.7131C6.04944 14.8716 5.99686 15.0545 5.99676 15.241V15.9998L5.99773 16.0017L5.99968 16.0027H17.9997L18.0016 16.0017V15.241L17.9919 15.1017C17.9726 14.9643 17.9252 14.8319 17.8516 14.7131C17.7533 14.5546 17.6125 14.426 17.4455 14.3429L17.4396 14.34L15.6591 13.44C15.1627 13.1918 14.7448 12.8102 14.4523 12.3384C14.1584 11.8645 14.0026 11.3181 14.0023 10.7605V6.99976C14.0024 6.47014 14.2122 5.96194 14.5867 5.58743C14.9612 5.21292 15.4694 5.0031 15.999 5.00301C16.2649 5.00301 16.5201 4.89688 16.7081 4.70885C16.8961 4.52083 17.0023 4.26567 17.0023 3.99976ZM18.9971 3.99976C18.9971 4.79472 18.6806 5.55712 18.1185 6.11924C17.5564 6.68137 16.794 6.99782 15.999 6.99782H15.9971V10.7595L16.0068 10.8988C16.0262 11.0362 16.0735 11.1687 16.1471 11.2874C16.2209 11.4064 16.3187 11.508 16.4334 11.5865L16.5533 11.6566L16.5591 11.6595L18.3318 12.5566C18.8311 12.8047 19.2526 13.1874 19.5464 13.6611C19.8403 14.135 19.9961 14.6824 19.9964 15.24V15.9998C19.9964 16.5294 19.7864 17.0375 19.412 17.4121C19.0375 17.7866 18.5293 17.9974 17.9997 17.9975H12.9971V21.9998C12.9971 22.5505 12.5504 22.997 11.9997 22.9972C11.4488 22.9972 11.0023 22.5506 11.0023 21.9998V17.9975H5.99968C5.46994 17.9975 4.96193 17.7867 4.58734 17.4121C4.21276 17.0375 4.00195 16.5295 4.00195 15.9998V15.24L4.00975 15.0306C4.04386 14.5461 4.1949 14.0757 4.45195 13.6611C4.70917 13.2464 5.06337 12.9018 5.48247 12.6559L5.66559 12.5566L7.43929 11.6605L7.44513 11.6566C7.61215 11.5736 7.753 11.4459 7.8513 11.2874C7.94944 11.1292 8.00201 10.9467 8.00228 10.7605V6.99976L8.0013 6.99782H7.99936C7.2044 6.99782 6.442 6.68137 5.87988 6.11924C5.31785 5.55714 5.00228 4.79465 5.00228 3.99976C5.00236 3.20492 5.31783 2.44233 5.87988 1.88028C6.44198 1.31826 7.20447 1.00269 7.99936 1.00269H15.999C16.7938 1.00269 17.5564 1.31836 18.1185 1.88028C18.6806 2.44233 18.997 3.20492 18.9971 3.99976Z" fill="currentColor" stroke="none" className="pin-shape"/>
</svg>);
}

export function FolderOpenIcon(props: SVGProps<SVGSVGElement>) {
  return (<svg {...props} className="micro-icon folder-open" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path className="part part-0" pathLength="1" d="m6 14 1.5-2.9A2 2 0 0 1 9.24 10H20a2 2 0 0 1 1.94 2.5l-1.54 6a2 2 0 0 1-1.95 1.5H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H18a2 2 0 0 1 2 2v2"/></svg>);
}

export function FolderMinusIcon(props: SVGProps<SVGSVGElement>) {
  return (<svg {...props} className="micro-icon folder-minus" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path className="part part-0" pathLength="1" d="M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"/><path className="part part-1" pathLength="1" d="M9 13h6"/></svg>);
}

export function FolderTreeIcon(props: SVGProps<SVGSVGElement>) {
  return (<svg {...props} className="micro-icon folder-tree" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path className="part part-0" pathLength="1" d="M20 10a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1h-2.5a1 1 0 0 1-.8-.4l-.9-1.2A1 1 0 0 0 15 3h-2a1 1 0 0 0-1 1v5a1 1 0 0 0 1 1Z"/><path className="part part-1" pathLength="1" d="M20 21a1 1 0 0 0 1-1v-3a1 1 0 0 0-1-1h-2.9a1 1 0 0 1-.88-.55l-.42-.85a1 1 0 0 0-.92-.6H13a1 1 0 0 0-1 1v5a1 1 0 0 0 1 1Z"/><path className="part part-2" pathLength="1" d="M3 5a2 2 0 0 0 2 2h3"/><path className="part part-3" pathLength="1" d="M3 3v13a2 2 0 0 0 2 2h3"/></svg>);
}

export function PanelLeftOpenIcon(props: SVGProps<SVGSVGElement>) {
  return (<svg {...props} className="micro-icon panel-left-open" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><rect className="part part-0" pathLength="1" height="18" rx="2" width="18" x="3" y="3"/><path className="part part-1" pathLength="1" d="M9 3v18"/><path className="part part-2" pathLength="1" d="m14 9 3 3-3 3"/></svg>);
}

export function PanelRightOpenIcon(props: SVGProps<SVGSVGElement>) {
  return (<svg {...props} className="micro-icon panel-right-open" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><rect className="part part-0" pathLength="1" height="18" rx="2" width="18" x="3" y="3"/><path className="part part-1" pathLength="1" d="M15 3v18"/><path className="part part-2" pathLength="1" d="m10 15-3-3 3-3"/></svg>);
}

export function SquarePenIcon(props: SVGProps<SVGSVGElement>) {
  return (<svg {...props} className="micro-icon square-pen" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path className="part part-0" pathLength="1" d="M12 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path className="part part-1" pathLength="1" d="M18.375 2.625a1 1 0 0 1 3 3l-9.013 9.014a2 2 0 0 1-.853.505l-2.873.84a.5.5 0 0 1-.62-.62l.84-2.873a2 2 0 0 1 .506-.852z"/></svg>);
}

export function AlignLeftIcon(props: SVGProps<SVGSVGElement>) {
  return (<svg {...props} className="micro-icon align-left" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><line className="part part-0" pathLength="1" x1="3" x2="21" y1="6" y2="6"/><line className="part part-1" pathLength="1" x1="3" x2="15" y1="12" y2="12"/><line className="part part-2" pathLength="1" x1="3" x2="17" y1="18" y2="18"/></svg>);
}

export function BookOpenTextIcon(props: SVGProps<SVGSVGElement>) {
  return (<svg {...props} className="micro-icon book-open-text" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><path className="center-line" d="M12 7v14"  /><path className="text-line text-line-right-bottom" d="M16 12h2"  /><path className="text-line text-line-right-top" d="M16 8h2"  /><path className="book-path"
				d="M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z"
			 /><path className="text-line text-line-left-bottom" d="M6 12h2"  /><path className="text-line text-line-left-top" d="M6 8h2"  /></svg>);
}


export function SearchIcon(props: SVGProps<SVGSVGElement>) {
  return (<svg {...props} className="micro-icon search" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false"><g className="search-scan"><path d="m21 21-4.34-4.34"/><circle cx="11" cy="11" r="8"/></g></svg>);
}

export function GlobeIcon(props: SVGProps<SVGSVGElement>) {
  return (<svg {...props} className="micro-icon globe" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="10"/><path className="mi-globe-meridian" d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/><path d="M2 12h20"/></svg>);
}

export function DownloadIcon(props: SVGProps<SVGSVGElement>) {
  return (<svg {...props} className="micro-icon mi-download" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" /> <g className="mi-download-arrow"> <polyline points="7 10 12 15 17 10" /> <line x1="12" x2="12" y1="15" y2="3" /> </g></svg>);
}

export function BellIcon(props: SVGProps<SVGSVGElement>) {
  return (<svg {...props} className="micro-icon bell" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false"><g className="mi-bell-body"><path d="M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326" /> <path className="mi-bell-clapper" d="M10.268 21a2 2 0 0 0 3.464 0" /></g></svg>);
}

export function CircleHelpIcon(props: SVGProps<SVGSVGElement>) {
  return (<svg {...props} className="micro-icon circle-help" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false"><circle cx="12" cy="12" r="10" /> <g className="mi-help-question"> <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3" /> <path d="M12 17h.01" /> </g></svg>);
}

export function FolderTreeV2Icon(props: SVGProps<SVGSVGElement>) {
  return (<svg {...props} xmlns="http://www.w3.org/2000/svg" width="16" height="16" className="micro-icon folder-tree-v2" aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path className="upper folder" d="M20 10a1 1 0 0 0 1-1V6a1 1 0 0 0-1-1h-2.5a1 1 0 0 1-.8-.4l-.9-1.2A1 1 0 0 0 15 3h-2a1 1 0 0 0-1 1v5a1 1 0 0 0 1 1Z" pathLength="1"/><path className="lower folder" d="M20 21a1 1 0 0 0 1-1v-3a1 1 0 0 0-1-1h-2.9a1 1 0 0 1-.88-.55l-.42-.85a1 1 0 0 0-.92-.6H13a1 1 0 0 0-1 1v5a1 1 0 0 0 1 1Z" pathLength="1"/><path className="branch" d="M3 5a2 2 0 0 0 2 2h3" pathLength="1"/><path className="trunk" d="M3 3v13a2 2 0 0 0 2 2h3" pathLength="1"/></svg>);
}
